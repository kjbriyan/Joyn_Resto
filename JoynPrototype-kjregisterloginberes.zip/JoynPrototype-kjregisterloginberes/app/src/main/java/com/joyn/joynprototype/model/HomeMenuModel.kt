package com.joyn.joynprototype.model

data class HomeMenuModel(val nama: String, val icon: Int)