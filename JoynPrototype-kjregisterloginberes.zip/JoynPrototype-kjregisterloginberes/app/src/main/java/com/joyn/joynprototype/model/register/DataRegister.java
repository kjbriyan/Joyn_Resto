package com.joyn.joynprototype.model.register;

public class DataRegister {

    private String nama;
    private String username;
    private String password;

    public DataRegister(String nama, String username, String password) {
        this.nama = nama;
        this.username = username;
        this.password = password;
    }
}

