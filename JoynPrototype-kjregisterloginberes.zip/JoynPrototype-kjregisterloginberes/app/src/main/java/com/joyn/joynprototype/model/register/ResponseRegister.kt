package com.joyn.joynprototype.model.register

import com.google.gson.annotations.SerializedName


class ResponseRegister {

    @field:SerializedName("status")
    val status: String? = null
}